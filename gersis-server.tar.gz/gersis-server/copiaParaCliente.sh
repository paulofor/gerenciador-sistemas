./node_modules/.bin/lb-sdk server/server ~/aplicacoes/MarketingDigital/mktdigital-angular/src/app/shared/sdk -d ng2web
