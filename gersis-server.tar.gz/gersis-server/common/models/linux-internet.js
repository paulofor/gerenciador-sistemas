'use strict';

module.exports = function(Linuxinternet) {

};
