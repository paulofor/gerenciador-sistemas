'use strict';

module.exports = function(Metodoserver) {

};
