'use strict';

module.exports = function(Sistema) {

};
