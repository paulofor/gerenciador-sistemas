'use strict';

module.exports = function(Parametrometodoserver) {

};
