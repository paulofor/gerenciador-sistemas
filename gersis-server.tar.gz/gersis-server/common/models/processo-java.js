'use strict';

module.exports = function(Processojava) {

};
