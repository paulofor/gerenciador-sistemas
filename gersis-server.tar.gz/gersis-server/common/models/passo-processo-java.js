'use strict';

module.exports = function(Passoprocessojava) {

};
